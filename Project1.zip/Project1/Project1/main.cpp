#include <iostream>
#include <fstream>
#include <vector>


#pragma pack(push, 1)
struct BMPFileHeader {
    uint16_t file_type{0x4D42};       
    uint32_t file_size{0};            
    uint16_t reserved1{0};            
    uint16_t reserved2{0};            
    uint32_t offset_data{0}; 

    uint32_t size{ 0 };             
    int32_t width{ 0 };                  
    int32_t height{ 0 };             
    uint16_t planes{ 1 };                  
    uint16_t bit_count{ 0 };
};
#pragma pack(pop)

struct BMP {
    BMPFileHeader file_header;
    std::vector<uint8_t> data;
    std::vector<uint8_t> header_add;

    BMP(const char *fname) {
        read_file(fname);
    }

    void read_file(const char *fname) {
    	std:: ifstream image{fname, std::ios_base::binary};
        if (image) {
            image.read((char*)&file_header, sizeof(file_header));
            if(file_header.file_type != 0x4D42) {
                throw std::runtime_error("Error! Unrecognized file format.");
            }
            uint32_t pixel_count = file_header.bit_count / 8;
            std:: vector <uint8_t> padding_row((4 - pixel_count * file_header.width % 4)%4);
        
            header_add.resize(file_header.offset_data - sizeof(file_header));
            image.read((char*)header_add.data(), header_add.size());

            data.resize(file_header.width * pixel_count * file_header.height);
            for (int y = 0; y < file_header.height; ++y) {
                image.read((char*)data.data() + y * file_header.width*pixel_count, file_header.width * pixel_count);
                image.read((char *)padding_row.data(), padding_row.size());
            }
        } else {
            throw std::runtime_error("Unable to open the input image file.");
        }
        image.close();
    }

    void write_file(const char *fname) {
     	std:: ofstream fout{fname, std:: ios_base::binary};
        uint32_t pixel_count = file_header.bit_count / 8;
        std:: vector <uint8_t> padding_row((4 - pixel_count * file_header.width% 4)%4);
        if (fout) {
            fout.write((const char*)&file_header, sizeof(file_header));
            fout.write((const char*)header_add.data(), header_add.size());
            for (int y = 0; y < file_header.height; ++y){
                fout.write((const char*)data.data()+ y * file_header.width*pixel_count, file_header.width*pixel_count);
                fout.write((const char*)padding_row.data(), padding_row.size());

            }
        } else {
            throw std::runtime_error("Unable to open the output image file.");
        }
        fout.close();
    }

    void turn_right(){
        std::vector <uint8_t> new_data(data);
        uint32_t pixel_count = file_header.bit_count / 8;

        for (int y = 0; y < file_header.height; y++){
            for (int x = 0; x < file_header.width; x++){
                for (int pix_num = 0; pix_num < pixel_count; pix_num++) {
                    data[pixel_count * (file_header.height * (file_header.width - x - 1) + y) + pix_num] =\
                     new_data[pixel_count * (x + y * file_header.width) + pix_num];
                }
            }
        }
        std::swap(file_header.height,file_header.width);
    }

    void turn_left() {
        std::vector <uint8_t> new_data(data);
        uint32_t pixel_count = file_header.bit_count / 8;

        for (int y = 0; y < file_header.height; y++){
            for (int x = 0; x < file_header.width; x++){
                for (int pix_num = 0; pix_num < pixel_count; pix_num++) {
                    data[pixel_count * ((file_header.height - y - 1) + x * file_header.height)+pix_num] =\
                     new_data[pixel_count * (x + y * file_header.width) + pix_num];
                }
            }
        }
        std::swap(file_header.height,file_header.width);
    }
};

int main() {
    // в этом месте сам реши в каком порядке составишь прогу
    BMP bmp("test_24.bmp");                               //создаешь класс и сразу считываешь указанный файл
    std:: cout << "size test_24.bmp: " << bmp.file_header.file_size << "\n";      //вывод размера файла
    bmp.write_file("out1.bmp");                          //создание нового файла с указанным именем и запись в него текущих данных
    bmp.turn_right();                                    //поворот вправо
    bmp.write_file("out2.bmp");
    bmp.turn_left();                                     //поворот влево (вернет начальное состояние)
    bmp.turn_left();                                     //поворот влево х2
    bmp.write_file("out3.bmp");

}